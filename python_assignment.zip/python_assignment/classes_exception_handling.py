# Classes and Exception Handling in Python


class BankAccount:
    def __init__(self, owner, balance=0):
        self.owner = owner
        self.balance = balance

    def deposit(self, amount):
        try:
            if amount <= 0:
                raise ValueError("Deposit amount must be positive.")
            self.balance += amount
            print(f"Deposited ₹{amount}. New balance: ₹{self.balance}")
        except ValueError as e:
            print(f"❌ Error: {e}")

    def withdraw(self, amount):
        try:
            if amount > self.balance:
                raise ValueError("Insufficient balance.")
            self.balance -= amount
            print(f"Withdrew ₹{amount}. Remaining balance: ₹{self.balance}")
        except ValueError as e:
            print(f"❌ Error: {e}")


account = BankAccount("Rahul", 1000)

account.deposit(500)      
account.deposit(-200)       
account.withdraw(300)       
account.withdraw(2000)       