# Palindrome Checker
word = input("Enter a word: ")

# Convert to lowercase for case-insensitive comparison(if-elif-else)
if word.lower() == word[::-1].lower():
    print(f"'{word}' is a palindrome.")
elif len(word) < 3:
    print("Word is too short to be a palindrome.")
else:
    print(f"'{word}' is not a palindrome.")


# Sum of even numbers in a list(for loop)
numbers = [1, 4, 5, 6, 9, 12, 15, 20]
even_sum = 0

for num in numbers:
    if num % 2 == 0:
        even_sum += num

print("Sum of even numbers:", even_sum)

# While loop
correct_password = "admin123"
attempts = 3

while attempts > 0:
    entered = input("Enter your password: ")

    if entered == correct_password:
        print("Access granted.")
        break
    else:
        attempts -= 1
        print(f"Wrong password. {attempts} attempt(s) left.")

if attempts == 0:
    print("Account locked due to too many failed attempts.")