def wrapper(func):
    def inner():
        print("Hello!")
        func()
        print("Goodbye!")
    return inner

@wrapper
def say_hello():
    print("My name is Python.")

say_hello()