# Function with parameter passing and return value
def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

# Function with default parameter
def multiply(number, factor=2):
    return number * factor

# Example usage
print(multiply(5))      # Output: 10 (uses default factor=2)