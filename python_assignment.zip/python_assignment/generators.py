def count_up_to(n):
    num = 1
    while num <= n:
        yield num
        num += 1
# Unlike lists, it doesn’t store all values — it yields one at a time.
gen = count_up_to(3)
print(next(gen))  
print(next(gen))  
print(next(gen))  