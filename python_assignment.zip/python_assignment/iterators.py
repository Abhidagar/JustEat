numbers = [1, 2, 3]
it = iter(numbers)       # create iterator

print(next(it)) 
print(next(it))  
print(next(it))  