# math_utils.py
def square(num):
    return num * num


def cube(num):
    return num ** 3


def is_even(num):
    return num % 2 == 0