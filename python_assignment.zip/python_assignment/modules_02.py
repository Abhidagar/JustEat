import modules_01
print(modules_01.square(5))    
print(modules_01.cube(3))       
print(modules_01.is_even(4))    
print(modules_01.is_even(7))     