# === 1. Arithmetic Operators ===
a = 10
b = 3
print("Arithmetic Operators:")
print(f"{a} + {b} = {a + b}")     # Addition
print(f"{a} - {b} = {a - b}")     # Subtraction
print(f"{a} * {b} = {a * b}")     # Multiplication
print(f"{a} / {b} = {a / b}")     # Division
print(f"{a} % {b} = {a % b}")     # Modulus
print(f"{a} ** {b} = {a ** b}")   # Exponentiation

print("\n")

# === 2. Comparison Operators ===

print("Comparison Operators:")
print(f"{a} == {b}: {a == b}")
print(f"{a} != {b}: {a != b}")
print(f"{a} > {b}: {a > b}")
print(f"{a} < {b}: {a < b}")
print(f"{a} >= {b}: {a >= b}")
print(f"{a} <= {b}: {a <= b}")

print("\n")

# === 3. Logical Operators ===
x = True
y = False
print("Logical Operators:")
print(f"x and y: {x and y}")
print(f"x or y: {x or y}")
print(f"not x: {not x}")

print("\n")

# === 4. Bitwise Operators ===
m = 5   # 0101
n = 3   # 0011
print("Bitwise Operators:")
print(f"{m} & {n} = {m & n}")   # AND
print(f"{m} | {n} = {m | n}")   # OR
print(f"{m} ^ {n} = {m ^ n}")   # XOR
print(f"~{m} = {~m}")           # NOT
print(f"{m} << 1 = {m << 1}")   # Left shift
print(f"{m} >> 1 = {m >> 1}")   # Right shift

print("\n")